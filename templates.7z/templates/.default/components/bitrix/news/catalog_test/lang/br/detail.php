<?
$MESS["CATEGORIES"] = "Informações relacionadas:";
$MESS["T_NEWS_DETAIL_BACK"] = "Voltar à lista";
?>