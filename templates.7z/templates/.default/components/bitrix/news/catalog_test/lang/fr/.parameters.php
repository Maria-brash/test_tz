<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Afficher la date de l'élément";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Afficher l'image pour l'annonce";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Ne pas ouvrir la barre de signets sociaux Par Défaut";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "clé pour bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "nom d'utilisateur pour bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Signets et réseaux sociaux utilisés";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Modèle du composant du panneau des signets sociaux";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Afficher le texte de l'annonce";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Afficher le panneau des signets sociaux";
?>