<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Exibir data do elemento";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Exibir imagem de visualização elemento";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Ocultar Barra de Favoritos de Rede Social por padrão";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "Chave bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "Login bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Usar Redes Sociais e Favoritos";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Modelo de favoritos de Redes Sociais";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Mostrar texto de visualização elemento";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Mostrar barra de favoritos de Redes Sociais";
?>