<?
$MESS["SEARCH_LABEL"] = "Szukaj:";
?>