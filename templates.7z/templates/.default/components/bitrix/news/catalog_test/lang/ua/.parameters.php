<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Виводити дату елемента";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Виводити зображення для анонсу";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Виводити текст анонсу";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Відображати панель соц. закладок";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "Ключ для bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "Логін для bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Не розкривати панель соц. закладок за умовчанням";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Соц. закладки та мережі, що використовуються";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Шаблон компонента панелі соц. Закладок";
?>