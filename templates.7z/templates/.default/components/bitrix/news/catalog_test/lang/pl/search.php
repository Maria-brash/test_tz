<?
$MESS["T_NEWS_DETAIL_BACK"] = "Wstecz do listy";
?>