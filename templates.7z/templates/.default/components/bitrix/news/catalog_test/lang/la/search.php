<?
$MESS["T_NEWS_DETAIL_BACK"] = "Regresar a la lista";
?>