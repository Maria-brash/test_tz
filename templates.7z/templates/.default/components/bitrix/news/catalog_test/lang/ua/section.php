<?
$MESS["SEARCH_LABEL"] = "Пошук:";
?>