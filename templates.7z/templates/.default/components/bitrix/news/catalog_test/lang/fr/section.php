<?
$MESS["SEARCH_LABEL"] = "Recherche : ";
?>