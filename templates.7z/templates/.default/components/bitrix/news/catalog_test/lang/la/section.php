<?
$MESS["SEARCH_LABEL"] = "Buscar:";
?>