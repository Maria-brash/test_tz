<?
$MESS["CATEGORIES"] = "Матеріали за темою:";
$MESS["T_NEWS_DETAIL_BACK"] = "Повернення до списку";
?>