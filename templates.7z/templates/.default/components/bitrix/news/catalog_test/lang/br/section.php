<?
$MESS["SEARCH_LABEL"] = "Pesquisar:";
?>