<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Afficher la date de l'élément";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Afficher la dénomination de l'élément";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Afficher l'image pour l'annonce";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Afficher le texte de l'annonce";
?>