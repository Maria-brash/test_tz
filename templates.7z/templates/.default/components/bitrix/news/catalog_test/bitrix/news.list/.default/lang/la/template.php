<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Toda la información relacionada con este registro será eliminada. ¿Desea continuar de todas maneras?";
?>