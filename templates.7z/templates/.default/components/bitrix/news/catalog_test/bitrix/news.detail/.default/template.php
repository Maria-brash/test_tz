<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>
<div class="product-card">
	<div class="product-card__info">
		<span class="product-card__title">
			<?= $arResult["NAME"] ?>
			<div class="stars"></div>
		</span>

		<span>
			<span class="price">₽ <?=$arResult['PROPERTIES']['PRICE']['VALUE']?></span>
			<strike class="old_price"><?=$arResult['PROPERTIES']['PRICE']['DESCRIPTION']?></strike>
		</span>

		<div class="actions">
			<?foreach ($arResult['PROPERTIES']['COLOR']['VALUE_XML_ID'] as $val):?>
				<a class="share-button" style="background:<?=$val?>" href="#"></a>
			<?endforeach;?>
			<br>
			<?foreach ($arResult['PROPERTIES']['SIZE']['VALUE'] as $val):?>
				<a class="share-button" href="#"><?=$val?></a>
			<?endforeach;?>
		</div>

		<div class="v21-product-buttons">	
			<a href="#" class="v21-product-buttons__item v21-border-button btn-default btn-sm">Купить</a>
			<a href="#" class="v21-product-buttons__item v21-border-button btn-default btn-sm">В избранное</a>
		</div>
		
		<?if ($arResult["DETAIL_TEXT"]) {?>
			<p class="v21-product-card__brief"><?= $arResult["DETAIL_TEXT"] ?></p>
		<?} elseif ($arResult["PREVIEW_TEXT"]) {?>
			<p class="v21-product-card__brief"><?= $arResult["PREVIEW_TEXT"] ?></p>
		<?}?>
		

		<div class="v21-product-card__specs">
			<div class="v21-product-card__specs-item"><span><?=$arResult['PROPERTIES']['SEASON']['NAME']?></span><span><?=$arResult['PROPERTIES']['SEASON']['VALUE']?></span></div>
			<div class="v21-product-card__specs-item"><span><?=$arResult['PROPERTIES']['MATERIAL']['NAME']?></span><span><?=$arResult['PROPERTIES']['MATERIAL']['VALUE']?></span></div>
		</div>
	</div><!-- /.product-card__info -->

	<? if (count($arResult["DISPLAY_PROPERTIES"]["IMG"]["FILE_VALUE"]) > 0) { ?>
		<div class="slider-container">
    		<div class="slider">
				<?foreach ($arResult["DISPLAY_PROPERTIES"]["IMG"]["FILE_VALUE"] as $photo) {?>
					<img src="<?= $photo["SRC"] ?>">
				<?}?>
			</div>
			<button class="prev-button">&lt;</button>
			<button class="next-button">&gt;</button>
  		</div>
	<? } ?>
</div><!-- /.product-card -->

<script>
	const slider = document.querySelector('.slider');
	const prevButton = document.querySelector('.prev-button');
	const nextButton = document.querySelector('.next-button');
	const slides = Array.from(slider.querySelectorAll('img'));
	const slideCount = slides.length;
	let slideIndex = 0;

	prevButton.addEventListener('click', showPreviousSlide);
	nextButton.addEventListener('click', showNextSlide);

	function showPreviousSlide() {
		slideIndex = (slideIndex - 1 + slideCount) % slideCount;
		updateSlider();
	}

	function showNextSlide() {
		slideIndex = (slideIndex + 1) % slideCount;
		updateSlider();
	}

	function updateSlider() {
		slides.forEach((slide, index) => {
			if (index === slideIndex) {
			slide.style.display = 'block';
			} else {
			slide.style.display = 'none';
			}
		});
	}

	updateSlider();
</script>