<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Mostrar fecha del elemento";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Mostrar título del elemento";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Mostrar imagen previa del elemento";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Ocultar barra de marcadores de red social por defecto";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "Clave bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "Conexión bit.ly";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Usar redes sociales y marcadores";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Plantilla de marcadores de redes sociales";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Mostrar texto previo del elemento";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Mostrar barra de marcadores de redes sociales";
?>