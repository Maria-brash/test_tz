<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Toutes les informations associées à cet enregistrement seront effacées. Continuer ?";
?>