<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display daty elementu";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Wyświetl tytuł elementu";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display obrazu szczegułów elementu";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Ukryj domyślnie belkę zakładek sieci społecznościowej";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "bit.ly Klucz";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "bit.ly Login";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Użyj sieci społecznościowej i zakładek";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Szablon zakładek sieci społecznościowej";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display tekstu wstępu elementu";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Pokaż belkę zakładek seci społecznościowej";
?>