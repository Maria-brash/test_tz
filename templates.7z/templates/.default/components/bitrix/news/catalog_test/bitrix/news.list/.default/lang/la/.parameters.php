<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Mostrar fecha del elemento";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Mostrar título del elemento";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Mostrar imagen previa del elemento";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Mostrar texto previo del elemento";
?>