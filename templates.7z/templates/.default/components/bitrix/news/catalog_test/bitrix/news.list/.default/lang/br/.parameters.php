<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Exibir data do elemento";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Mostrar título do elemento";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Exibir imagem de visualização elemento";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Mostrar texto de visualização elemento";
?>