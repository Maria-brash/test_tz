<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Toda a informação relacionada a este registro será excluída. Continuar?";
?>