<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Wszystkie informacje powiązane z tym rekordem zostaną usunięte. Kontynuować mimo to?";
?>