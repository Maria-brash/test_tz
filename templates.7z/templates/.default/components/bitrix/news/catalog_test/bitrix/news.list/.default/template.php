<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>
<div class="cards">
	<?foreach($arResult['ITEMS'] as $arItem):?>
		<div class="item">
			<div class="product">
				<div class="thumb-img">
					<img src="<?=$arItem['PREVIEW_PICTURE']['SRC']?>">
					<div class="actions">
						<?foreach ($arItem['PROPERTIES']['COLOR']['VALUE_XML_ID'] as $val):?>
							<a class="share-button" style="background:<?=$val?>" href=""></a>
						<?endforeach;?>
						<br>
						<?foreach ($arItem['PROPERTIES']['SIZE']['VALUE'] as $val):?>
							<a class="share-button" href=""><?=$val?></a>
						<?endforeach;?>
						<a href="#" class="add-to-cart">В избранное</a>
					</div>
				</div>
				<div class="product-about">
					<h3 class="product-title">
						<a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a>
						<div class="stars"></div>
					</h3>
					<span class="price">₽ <?=$arItem['PROPERTIES']['PRICE']['VALUE']?></span>
					<strike><?=$arItem['PROPERTIES']['PRICE']['DESCRIPTION']?></strike>
				</div>
			</div>
		</div>
	<?endforeach;?>
</div>