<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display daty elementu";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Wyświetl tytuł elementu";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display obrazka wstępu elementu";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display tekstu wstępu elementu";
?>