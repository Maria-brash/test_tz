<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Виводити дату елемента";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Виводити зображення для анонсу";
$MESS["T_IBLOCK_DESC_NEWS_NAME"] = "Виводити назву елемента";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Виводити текст анонсу";
?>