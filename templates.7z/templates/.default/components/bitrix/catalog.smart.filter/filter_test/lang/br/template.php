<?
$MESS["CT_BCSF_DEL_FILTER"] = "Redefinir";
$MESS["CT_BCSF_FILTER_COUNT"] = "Selecionado: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_FROM"] = "De";
$MESS["CT_BCSF_FILTER_SHOW"] = "Mostrar";
$MESS["CT_BCSF_FILTER_TITLE"] = "Selecionar por:";
$MESS["CT_BCSF_FILTER_TO"] = "Para";
$MESS["CT_BCSF_SET_FILTER"] = "Mostrar";
?>