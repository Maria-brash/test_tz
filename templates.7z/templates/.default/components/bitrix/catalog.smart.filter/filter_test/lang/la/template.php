<?
$MESS["CT_BCSF_DEL_FILTER"] = "Restaurar ";
$MESS["CT_BCSF_FILTER_ALL"] = "Todo";
$MESS["CT_BCSF_FILTER_COUNT"] = "Seleccionado: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_FROM"] = "De";
$MESS["CT_BCSF_FILTER_SHOW"] = "Mostrar";
$MESS["CT_BCSF_FILTER_TITLE"] = "Seleccione por:";
$MESS["CT_BCSF_FILTER_TO"] = "Para";
$MESS["CT_BCSF_SET_FILTER"] = "Mostrar";
?>