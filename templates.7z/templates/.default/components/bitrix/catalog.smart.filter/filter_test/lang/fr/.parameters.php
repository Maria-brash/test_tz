<?
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Affichage d'éléments";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "horizontal";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "vertical";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "Afficher les informations de filtre contextuel";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "sur la gauche";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "droite";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "Thème de couleur";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "espace des thèmes";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "bleu (sujet par défaut)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "vert";
$MESS["CP_BCT_TPL_THEME_RED"] = "Rouge";
$MESS["CP_BCT_TPL_THEME_SITE"] = "Prendre le thème dans les paramètres du site (pour la solution bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "arbre";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "jaune";
$MESS["TP_BCSF_DISPLAY_ELEMENT_COUNT"] = "Afficher la quantité";
?>