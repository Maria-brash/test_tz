<?
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Tryb widoku";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "Pionowo";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "Poziomo";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "Pokaż wyskakujące informacje filtra";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "po lewej";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "po prawej";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "Kolor motywu";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "ciemny";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "niebieski (domyślny motyw)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "Zielony";
$MESS["CP_BCT_TPL_THEME_RED"] = "Czerwony";
$MESS["CP_BCT_TPL_THEME_SITE"] = "Użyj motywu strony (dla bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "drewno";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "żółty";
$MESS["TP_BCSF_DISPLAY_ELEMENT_COUNT"] = "Pokaż ilość";
?>