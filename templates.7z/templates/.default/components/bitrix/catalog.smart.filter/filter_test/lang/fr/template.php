<?
$MESS["CT_BCSF_DEL_FILTER"] = "Annuler";
$MESS["CT_BCSF_FILTER_ALL"] = "Tous";
$MESS["CT_BCSF_FILTER_COUNT"] = "Sélectionné: #ELEMENT_COUNT#";
$MESS["CT_BCSF_FILTER_FROM"] = "De";
$MESS["CT_BCSF_FILTER_SHOW"] = "Afficher";
$MESS["CT_BCSF_FILTER_TITLE"] = "Choix selon les paramètres : ";
$MESS["CT_BCSF_FILTER_TO"] = "Dans";
$MESS["CT_BCSF_SET_FILTER"] = "Afficher";
?>