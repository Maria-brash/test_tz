<?
$MESS["CP_BCT_TPL_FILTER_VIEW"] = "Modo de visualización";
$MESS["CP_BCT_TPL_FILTER_VIEW_H"] = "horizontal";
$MESS["CP_BCT_TPL_FILTER_VIEW_V"] = "vertical";
$MESS["CP_BCT_TPL_POPUP_POSITION"] = "Mostrar información de filtro emergente";
$MESS["CP_BCT_TPL_POPUP_POSITION_LEFT"] = "a la izquierda";
$MESS["CP_BCT_TPL_POPUP_POSITION_RIGHT"] = "a la derecha";
$MESS["CP_BCT_TPL_TEMPLATE_THEME"] = "Color del tema";
$MESS["CP_BCT_TPL_THEME_BLACK"] = "oscuro";
$MESS["CP_BCT_TPL_THEME_BLUE"] = "azul (tema por defecto)";
$MESS["CP_BCT_TPL_THEME_GREEN"] = "verde";
$MESS["CP_BCT_TPL_THEME_RED"] = "Rojo";
$MESS["CP_BCT_TPL_THEME_SITE"] = "Utilizar el tema del sitio web (para bitrix.eshop)";
$MESS["CP_BCT_TPL_THEME_WOOD"] = "madera";
$MESS["CP_BCT_TPL_THEME_YELLOW"] = "amarillo";
$MESS["TP_BCSF_DISPLAY_ELEMENT_COUNT"] = "Mostrar la cantidad";
?>