<?
$sSectionName = "Тестовый каталог";
$arDirProperties = Array(
   "TITLE" => "Кардиганы"
);
?>